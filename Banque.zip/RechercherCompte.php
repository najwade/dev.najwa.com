 <?php include("head.php");?>
<!DOCTYPE html>
<html>
<head>
<title>Formulaire de recherche</title>
</head>
<body>
														
<form method="POST" action="RechercheCompte.php">

   
 <pre>  
   
<h1>Chercher un compte</h1>
                                                          
															
Saisir le nom du client :  <input type="text" name="Nom_Clt" size="40">
									


                                                 <input type="submit" value="chercher" name="chercher"><input type="reset" value="R�tablir" name="B2">
</pre>
	
</form>
</body>
</html>