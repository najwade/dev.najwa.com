 <?php include("head.php");?>    
<html>

<head>
<meta http-equiv="Content-Language" content="fr">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Ajouter Coureuse</title>
</head>

<body>


  <h2>Gestion des  Op�rations   </h2>
  
</body>

</html>