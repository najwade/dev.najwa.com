<html>

<head>
<meta http-equiv="Content-Language" content="fr">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Gestion Operation</title>
</head>

<body>

<table table border="1" width="100%" height="95" bordercolorlight="#FFFFF" bordercolordark="#FFFFFF"  >
	<tr>
		<td width="300" bgcolor="#FFCCFF" align="center"><a href="SaisirOperation.php">Ajouter Op�ration</a></td>
		<td width="300" bgcolor="#FFCCFF" align="center"><a href="PointerOperation.php">Pointer Op�ration </a></td>
		<td width="300" bgcolor="#FFCCFF" align="center"><a href="RechercherCompte.php">Chercher Compte</td>
		<td width="300" bgcolor="#FFCCFF" align="center"><a href="ajouter_compte.php">Ajouter Compte</a></td>
	</tr>
</table>

</body>

</html>
