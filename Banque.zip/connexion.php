<?php
if($bdd = mysqli_connect('localhost', 'root', '', 'banque'))
{
      echo '       ';                                                                                  
}
else
{
    echo 'erreur de connexion avec la base de donnee mabase';                                                             
}
?>
